# IHDRAT
## Integrated Holistic Development Research & Assessment Tool

A Progressive Web App (PWA) for research scholars measuring the effectiveness of holistic child development programmes for Std. 3 to 5.

### Domains Covered
- **Cognitive** – Bloom's Taxonomy (Knowledge → Evaluation)
- **Affective** – Krathwohl's Taxonomy (Attitudes, Values, Motivation)
- **Psychomotor** – Dave's Taxonomy (Motor Skills, Coordination)

### Research Design
- Mixed Method (Qualitative + Quantitative)
- Experimental Design (Pre-Test / Mid-Test / Post-Test)
- 3-Year Programme Duration
- Experimental & Control Group Comparison

### Features
- Student Registry with Experimental/Control grouping
- Domain-wise Score Entry (Pre / Mid / Post)
- Automatic Gain Score & Cohen's d Effect Size Calculation
- Qualitative Data Recording (Observations, Interviews, Focus Groups)
- CSV Export for SPSS / Excel Analysis
- Data Backup & Restore
- Works fully offline as a PWA

### How to Install on Mobile
1. Open the app URL in Chrome
2. Tap **"Install IHDRAT App"** button OR
3. Tap Chrome menu (⋮) → **Add to Home Screen**

### Developed for
Educational Research · NEP 2020 Aligned · UGC/NCERT Compatible
